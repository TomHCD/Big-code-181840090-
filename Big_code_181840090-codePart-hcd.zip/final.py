import reliability
import Calculate
DLk= Calculate.Lk*(Calculate.Dk/0.4)*(reliability.Bk/0.8)
print(DLk)

g0=0.32
g1=0.2855
g2=0.2828
g3=0.2833
g4=(g0+g1+g2+g3+DLk)/5
print(g4)