#信度计算
t=82                            #题目数量
sumS2=121290                    #样本方差之和
sumS=138990                     #总体方差
Bk=(t/(t-1))*(1-(sumS2/sumS))   #信度
print(Bk)
