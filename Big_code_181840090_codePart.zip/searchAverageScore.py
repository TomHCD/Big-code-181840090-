import json
import urllib.request, urllib.parse
import os
import sys
import importlib
import csv

importlib.reload(sys)

f = open('/Users/huangchengdo/Desktop/test_data.json', encoding='utf-8')
res = f.read()
data = json.loads(res)
#print(data)

k=3544
content = open("/Users/huangchengdo/Desktop/Student2.csv",'w',encoding="utf-8")
while k<100000:
    try:
        print(data[str(k)]["user_id"])
        i=0
        cases = data[str(k)]['cases']
        scores = data[str(k)]['cases'][i]['upload_records']
        while i < len(cases):
            scores = data[str(k)]['cases'][i]['upload_records']
            for score in scores:
                print(cases[i]["case_id"],',',data[str(k)]["user_id"],',',cases[i]["case_type"],',',cases[i]["final_score"],
                      ',',score["score"],file=content)
            i = i + 1
    except KeyError:
        k=k+1
    else:
        k=k+1
    finally:
        pass