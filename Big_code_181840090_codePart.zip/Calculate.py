
k=4

#失分率计算
Xk=3916.7                          #第k次测试题中考生试题的得分之和
nk=113                             #第k次测试题中提交答案人次
SumXk=8716.77                      #从第1次到第k次考试中全体考生试题得分之和的和
Sumnk=281                          #从第1次到第k次考试中提交答案人次之和
Lk=1-(Xk/(100*nk))                 #失分率
for i in range(1,k+1):
    SumXk=SumXk+Xk
    Sumnk=Sumnk+nk
L1k=1-(SumXk/(100*Sumnk))          #累计失分率
print(Lk,L1k)

#区分度计算

XHighk=92.47                       #高分组平均成绩（前27%）
XLowk=0                            #低分组平均成绩（后27%）
Dk = (XHighk - XLowk)/100          #第k次考试中的区分度
print(Dk)

